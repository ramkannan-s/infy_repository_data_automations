#! /bin/bash

### Exit the script on any failures
set -eo pipefail
set -e
set -u

### Get Arguments
SOURCE_JPD_URL="${1:?please enter JPD URL. ex - https://ramkannan.jfrog.io}"
USER_NAME="${2:?please provide the username in JPD . ex - admin}"
JPD_AUTH_TOKEN="${3:?please provide the identity token}"

### define variables
reposfile="repos_list_federated.txt"

### Run the curl API 
rm -rf *.json
rm -rf *.txt

curl -X GET -H 'Content-Type: application/json' -u "${USER_NAME}":"${JPD_AUTH_TOKEN}" "${SOURCE_JPD_URL}/artifactory/api/repositories?type=federated" -s | jq -rc '.[] | .key' > $reposfile
cat "repos_list_federated.txt"

while IFS= read -r repoadd; do
    echo -e "\nExporting JSON for $repoadd from $SOURCE_JPD_URL"
    curl -X GET -u "${USER_NAME}":"${JPD_AUTH_TOKEN}" "$SOURCE_JPD_URL/artifactory/api/repositories/$repoadd" -s > "$repoadd.json"
    memberurlcount=$(cat "$repoadd.json" | jq .members | grep url | wc -l | xargs)
    echo -e "Member URL Count = $memberurlcount"
    if [[ "$memberurlcount" == "2" ]]; then
      echo -e ""
    else 
      echo "Check repo ==> $repoadd"
    fi
done < $reposfile

### sample cmd to run - ./fed_member_url_check.sh https://ramkannan.jfrog.io admin ****