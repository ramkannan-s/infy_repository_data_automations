#! /bin/bash

### Exit the script on any failures
set -eo pipefail
set -e
set -u

### Get Arguments
SOURCE_JPD_URL="${1:?please enter JPD URL. ex - https://ramkannan.jfrog.io}"
USER_NAME="${2:?please provide the username in JPD . ex - admin}"
JPD_AUTH_TOKEN="${3:?please provide the identity token}"

### define variables
reposfile="fedrepossync.txt"

### Run the curl API 
rm -rf *.json

while IFS= read -r repo; do
    echo -e "\nPerforming Sync for $repo"
    curl -XPOST -u "${USER_NAME}":"${JPD_AUTH_TOKEN}" "$SOURCE_JPD_URL/artifactory/api/federation/configSync/$repo"
    echo -e ""
done < $reposfile

### sample cmd to run - ./federated_repo_resync.sh https://ramkannan.jfrog.io admin ****
