#! /bin/bash

### Exit the script on any failures
set -eo pipefail
set -e
set -u

jpd1="ramkannan"
jpd2="proservice"

jf rt curl -XPOST api/search/aql -T list_artifacts_in_repo.aql --server-id=$jpd1 -s > jpd1.txt

jf rt curl -XPOST api/search/aql -T list_artifacts_in_repo.aql --server-id=$jpd2 -s > jpd2.txt

diff -y jpd1.txt jpd2.txt