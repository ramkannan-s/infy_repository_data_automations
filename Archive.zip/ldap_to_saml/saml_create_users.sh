#!/bin/bash

SOURCE_JPD_URL="${1:?please enter JPD URL. ex - https://ramkannan.jfrog.io}"
USER_NAME="${2:?please provide the username in JPD . ex - admin}" 
USER_TOKEN="${3:?please provide the identity token}"  


while IFS= read -r username; do
    echo -e "\nGenerating yaml for == $username =="
    cmd="cat user.json | jq ' .name = \"${username}\" ' | jq ' .email = \"${username}\" ' > $username.json"
    eval "$cmd" 
    echo -e "uploading yaml for == $username =="
    curl -XPUT -u $USER_NAME:$USER_TOKEN "$SOURCE_JPD_URL/artifactory/api/security/users/${username}" -d @"$username.json" -H 'Content-Type: application/json'
done < "saml_users_test.txt"

### sample cmd to run - ./saml_create_users.sh https://ramkannan.jfrog.io admin ****