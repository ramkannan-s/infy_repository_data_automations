#!/bin/bash

SOURCE_JPD_URL="${1:?please enter JPD URL. ex - https://ramkannan.jfrog.io}"
USER_NAME="${2:?please provide the username in JPD . ex - admin}" 
USER_TOKEN="${3:?please provide the identity token}"  

permissions_target_list="permissions_target_list.txt"

rm -rf *.txt
rm -rf *.json*

#curl -XGET -u $USER_NAME:$USER_TOKEN $SOURCE_JPD_URL/artifactory/api/security/users -s | jq -rc '.[] | select( .realm == "ldap" ) | .name' > ldap_users.txt

curl -XGET -u $USER_NAME:$USER_TOKEN "$SOURCE_JPD_URL/artifactory/api/security/permissions" -s | jq -rc '.[] | .name' | grep -v "INTERNAL" | sort | sed 's/ /%20/g' > $permissions_target_list

while IFS= read -r permissions; do
    echo -e "\nGetting JSON for Permission Target ==> $permissions"
    curl -XGET -u $USER_NAME:$USER_TOKEN "$SOURCE_JPD_URL/artifactory/api/security/permissions/$permissions" -s > $permissions.json
    curl -XGET -u $USER_NAME:$USER_TOKEN "$SOURCE_JPD_URL/artifactory/api/security/permissions/$permissions" -s | jq -rcS .principals.users | jq -r 'keys[]' > "$permissions"_UserList.txt
    if [[ !"$permissions" == *"Any%20Remote"* || "$permissions" == *"Anything"* ]]; then
        while IFS= read -r user; do
            if [[ "$user" == *"Any%20Remote"* ]]; then
                echo "Skip for $user"
            elif [[ "$user" == *"@ad.infosys.com"* ]]; then
                echo "Skip for $user"
            else 
                echo "updating for $user in $permissions.json"
                echo "sed -i -e 's/$user/$user\@ad.infosys.com/g' $permissions.json"
                sed -i -e 's/$user/$user\@ad.infosys.com/g' "$permissions.json"
                cat $permissions.json
            fi
        done < "$permissions"_UserList.txt
    fi
    #curl -XPUT -u $USER_NAME:$USER_TOKEN "$SOURCE_JPD_URL/artifactory/api/security/permissions/$permissions" -s -d @$permissions.json -H "Content-Type: application/json"
done < $permissions_target_list