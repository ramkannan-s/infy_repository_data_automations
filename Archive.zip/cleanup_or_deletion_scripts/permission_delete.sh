#! /bin/bash

### Exit the script on any failures
set -eo pipefail
set -e
set -u

### Get Arguments
SOURCE_JPD_URL="${1:?please enter JPD URL. ex - https://ramkannan.jfrog.io}"
USER_NAME="${2:?please provide the username in JPD . ex - admin}"
JPD_AUTH_TOKEN="${3:?please provide the identity token}"

### define variables
permissionnlist="permission_deletion_data.txt"

### Run the curl API 
while IFS= read -r permissionname; do
    echo -e "deleting permission == $permissionname =="
    curl -XDELETE -u $USER_NAME:$JPD_AUTH_TOKEN "$SOURCE_JPD_URL/artifactory/api/security/permissions/${permissionname}" -s
    echo -e ""
done < $permissionnlist

### sample cmd to run - ./permission_delete.sh https://ramkannan.jfrog.io admin ****