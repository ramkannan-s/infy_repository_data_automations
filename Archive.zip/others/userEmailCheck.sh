#! /bin/bash

### Exit the script on any failures
set -eo pipefail
set -e
set -u

### Get Arguments
SOURCE_JPD_URL="${1:?please enter JPD URL. ex - https://ramkannan.jfrog.io}"
USER_NAME="${2:?please provide the username in JPD . ex - admin}"
JPD_AUTH_TOKEN="${3:?please provide the user pwd or token or API Key . ex - password}"

rm -rf *.txt
rm -rf *.json

### define variables
userlist="users_saml_list.txt"

curl -XGET -u $USER_NAME:$JPD_AUTH_TOKEN "$SOURCE_JPD_URL/artifactory/api/security/users" -s | jq -rc '.[] | select( .realm == "saml" ) | .name' | sort > $userlist

### Run the curl API 
while IFS= read -r username; do
    curl -XGET -u $USER_NAME:$JPD_AUTH_TOKEN "$SOURCE_JPD_URL/artifactory/api/security/users/$username" -s > "$username.json"
    data=$(cat "$username.json" | jq .email | xargs)
    if [[ "$data" == null ]]; then
        echo "Email for $username is Empty !!!"
        echo "$username" >> "usermissingdata.txt"
    else
        echo "User $username <===> $data"
    fi
done < $userlist

rm -rf *.json

### sample cmd to run - ./userEmailCheck.sh https://ramkannan.jfrog.io admin ****