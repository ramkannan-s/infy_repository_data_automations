#! /bin/bash

SOURCE_JPD_URL="${1:?please enter JPD URL. ex - https://ramkannan.jfrog.io}"
USER_NAME="${2:?please provide the username in JPD . ex - admin}"
JPD_AUTH_TOKEN="${3:?please provide the identity token}"

../repos_scripts/getRepoList.sh "$SOURCE_JPD_URL" local "$USER_NAME" "$JPD_AUTH_TOKEN"

echo -e "\n"

echo "" > replicationrepo.txt

while IFS= read -r reponame; do
    data=$(curl -XGET -u $USER_NAME:$JPD_AUTH_TOKEN $SOURCE_JPD_URL/artifactory/api/replications/$reponame -s | grep message | xargs)
    if [[ $data == *"message"*  ]]; then
        echo "No Replication Configured for $reponame"
        echo "$reponame" >> replicationrepo.txt
    else
        echo "replication configured"
    fi
done < "repos_list_local.txt"

### sample cmd to run - ./checkReplicationConfigured.sh https://ramkannan.jfrog.io admin ****