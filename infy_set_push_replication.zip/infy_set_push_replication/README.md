# Setup Push Replication on Local Repository

## About this script and go plugin
The script `set-push-replication.sh` will get the list of local repositories using REST API cmd.
It will then install and invoke the set_push_replication go plugin. The plugin is used to create push replication for a set of local repos.

**Note:**
If you're planning to use the plugin separately, then install and use the plugin with options. For reference to [REST API Automation](https://www.jfrog.com/confluence/display/JFROG/Artifactory+REST+API) use this link.

## Sample command to run the shell script 
```bash
./setPushReplication.sh <source server url> <usernmae> <password or api key> <source server id> <target server url>

eg:
./setPushReplication.sh http://35.208.78.203:8082 admin ***** jfrog-test https://ramkannan.jfrog.io
```

## Installation with JFrog CLI
Build the plugin using GO

`$ go build -o set-push-replication`

and trigger the plugin using the cmd 

`$ ./set-push-replication spr "$SOURCE_JPD_ID" "$TARGET_JPD_URL" "$reponame"`

## Usage
### Commands
* clean
    - Arguments:
        - SOURCE_JPD_ID - The is the server id added as part of `jf config add` in your local terminal.
        - TARGET_JPD_URL - The is the target server url for which the replication URL will be added.
        - reponame - The local repo name in which the replication has to be setup.
    - Examples:
    ```
    $ ./set-push-replication spr eu https://ramkannans-apac-sbx.dev.gcp.devopsacc.team apline-local-1
    ```

### Environment variables
`jf config add` - to add the source server id.

## Additional info
`jf config show` - to view the list of added JFrog Server ID's
