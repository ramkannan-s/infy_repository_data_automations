#! /bin/bash

### Exit the script on any failures
set -eo pipefail
set -e

### Get Arguments
SOURCE_JPD_URL="${1:?please enter JPD URL. ex - http://35.208.78.203:8082}"
USER_NAME="${2:?please provide the username in JPD . ex - admin}"
USER_TOKEN="${3:?please provide the user pwd or token or API Key}"
SOURCE_JPD_ID="${4:?please enter JPD ID added in your local. ex - jfrog-test}"
TARGET_JPD_URL="${5:?please enter JPD URL. ex - https://ramkannan.jfrog.io}"
cron_value="${6:?please enter Cron Value. ex - 0 15 10 ? * *}"

### define variables
reposfile="local_repos_list.txt" 

### go build plugin and install plugin 
#jf plugin install set-push-replication
go build -o set-push-replication

### Run the curl API 
curl -X GET -H 'Content-Type: application/json' -u "${USER_NAME}":"${USER_TOKEN}" "$SOURCE_JPD_URL"/artifactory/api/repositories -s | jq -rc '.[] | select( .type == "LOCAL" ) | .key' > $reposfile

while read -r reponame; do
    echo -e "\nCheck if replication exist for $reponame"
    replicationurl=$(curl -X GET -u "${USER_NAME}":"${USER_TOKEN}" "$SOURCE_JPD_URL/artifactory/api/replications/$reponame" -s | jq -r '.[].url' || true)
    if [ "$replicationurl" == "$TARGET_JPD_URL/artifactory/$reponame" ]; then
        echo -e "Replication Exist, SKIPPING !!!"
    else
        echo -e "Setting Up Push Replication for Local Repo ===> $reponame"
        ./set-push-replication spr "$SOURCE_JPD_ID" "$TARGET_JPD_URL" "$reponame" "$cron_value"
    fi
done <$reposfile


### sample cmd to run - ./setPushReplication.sh http://35.208.78.203:8082 admin @World10 jfrog-test https://ramkannan.jfrog.io